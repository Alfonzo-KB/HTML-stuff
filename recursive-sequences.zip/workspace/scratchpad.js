//This creates the button
var button = document.createElement("button");
button.innerHTML = "Do Something";

//This puts it somewhere
var body = document.getElementsByTagName("body")[0];
body.appendChild(button);

//This gives the button an event handler
button.addEventListener("click", function(){
   alert("did something"); 
});

var title = document.createElement("title");
var textarea = document.createElement("textarea");
body.appendChild(textarea);